<?php
/**
 * fallback empty single gallery
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
